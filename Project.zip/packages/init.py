import mysql.connector
from packages import grafics

def create():
    try:
        user = grafics.read("Enter your database username: ")
        pas = grafics.read("Enter your database password: ")

        db = mysql.connector.connect(
            host="localhost",
            user=user,
            password=pas,
        )
        cur = db.cursor()
        cur.execute("CREATE DATABASE Tickets")
        cur.execute("CREATE DATABASE Trains")

        db = mysql.connector.connect(
            host="localhost",
            user=user,
            password=pas,
            database="Tickets"
        )
        cur = db.cursor()
        cur.execute(
            "create table booked (name varchar(255), age int, gender varchar(255), adh int, id INT AUTO_INCREMENT PRIMARY KEY, date varchar(255));")

        db = mysql.connector.connect(
            host="localhost",
            user=user,
            password=pas,
            database="Trains"
        )
        cur = db.cursor()
        cur.execute(
            "create table available (name varchar(255), cost int, source varchar(255), destination varchar(255), year int, id INT AUTO_INCREMENT PRIMARY KEY);")
        data = open("data.txt", "w")
        data.write(f"init ok`{user}`{pas}")
        data.close()
    except:
        grafics.push("Error in credentials. Try again.")
        create()

create()