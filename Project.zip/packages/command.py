def find_command(com):
    if "book" in com:
        return "booking"
    elif "cancel" in com:
        return "canceling"
    elif "show" in com:
        return "listAll"
    elif "list" in com:
        return "listAll"
    elif "details" in com:
        return "listAll"
    elif "exit" in com:
        return "exit"
    elif "end" in com:
        return "exit"
    elif "finish" in com:
        return "exit"
    elif "quit" in com:
        return "exit"
    elif "edit" in com:
        return "mod"
    elif "mod" in com:
        return "mod"
    elif "change" in com:
        return "mod"

def number(data):
    i=1
    for d in data:
        d["No."]=str(i)
        i+=1
    return data