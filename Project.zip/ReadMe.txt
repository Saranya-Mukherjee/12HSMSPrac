##
Please run the MINC.py file to run the entire project
##

Admin Username: "Admin"
Admin Passkey: "Password"

Name - Only full name allowed
Age - Only a numerical age will be accepted
Gender - Male/Female
Aadhar Number - Only numbers