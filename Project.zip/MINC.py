# This is the file you should run to start up the entire system
import packages.grafics as grafics

try:
    data = open("packages/data.txt", "r")
    data.close()
except:
    grafics.push("Staring Initialization Procedure...")
    import packages.init as init

while True:
    print("| Modes:\n| 1. User\n| 2. Administrator\n| 3. Exit\n")
    mode = int(grafics.read("Enter Mode(1,2,3)"))
    if mode == 1:
        from packages import user
        user.main()
        break
    elif mode == 2:
        print("| Refer to ReadMe.txt for these details.")
        while True:
            uname = grafics.read("Enter Username")
            if uname == "Admin":
                while True:
                    upass = grafics.read("Enter Password")
                    if upass == "Password":
                        from packages import admin
                        admin.main()
                        break
                    else:
                        print("| Invalid Password")
                break
            else:
                print("| Invalid Username")
        break
    elif mode==3:
        c = grafics.read(f"Confirm exit (y/n):")
        if c.lower() in "y":
            grafics.push("Thank you for using MINC")
            exit(101)
        if c.lower() in "n":
            continue
        else:
            grafics.push("Enter proper option.")
    else:
        print("| Please enter a proper option.")